<div class="user-sidebar">
    <ul>
        <li><a href="dashboard.php"><?php echo LANG_VALUE_89; ?></a></li>
        <li><a href="customer-profile-update.php"><?php echo LANG_VALUE_117; ?></a></li>
        <li><a href="customer-billing-shipping-update.php"><?php echo LANG_VALUE_88; ?></a></li>
        <li><a href="customer-password-update.php"><?php echo LANG_VALUE_99; ?></a></li>
        <li><a href="customer-order.php"><?php echo LANG_VALUE_24; ?></a></li>
        <li><a href="logout.php"><?php echo LANG_VALUE_14; ?></a></li>
    </ul>
</div>