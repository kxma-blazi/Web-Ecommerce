<?php
$serverName = "localhost";
$dbUsername = "slgs123";
$dbPassword = "fC@gELt1q@dKLwLi";
$dbName = "slgs";

$conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);

if (!$conn) {
    die("Connection failed : " .mysqli_connect_error());
} 